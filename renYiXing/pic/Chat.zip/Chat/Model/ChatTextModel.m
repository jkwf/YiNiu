//
//  ChatTextModel.m
//  SChatUI
//
//  Created by tongxuan on 16/7/27.
//  Copyright © 2016年 tongxuan. All rights reserved.
//

#import "ChatTextModel.h"

@implementation ChatTextModel

@end
