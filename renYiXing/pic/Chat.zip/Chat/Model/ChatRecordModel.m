//
//  ChatRecordModel.m
//  SChatUI
//
//  Created by tongxuan on 16/8/1.
//  Copyright © 2016年 tongxuan. All rights reserved.
//

#import "ChatRecordModel.h"

@implementation ChatRecordModel

@end
